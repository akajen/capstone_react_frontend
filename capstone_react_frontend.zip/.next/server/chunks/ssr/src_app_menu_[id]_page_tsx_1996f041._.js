module.exports = {

"[project]/src/app/menu/[id]/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>MenuItemPage)
});
function MenuItemPage({ params }) {
    const { id } = params;
    console.log(id);
}
}}),

};

//# sourceMappingURL=src_app_menu_%5Bid%5D_page_tsx_1996f041._.js.map