module.exports = {

"[project]/src/lib/useAddToCart.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "handleATCClick": (()=>handleATCClick),
    "useAddToCart": (()=>useAddToCart)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$3_$40$types$2b$react$40$_961aaeffa0f0daea64aa5e05def61fc9$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.3_@types+react@_961aaeffa0f0daea64aa5e05def61fc9/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
"use client";
;
const useAddToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$3_$40$types$2b$react$40$_961aaeffa0f0daea64aa5e05def61fc9$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        items: [],
        add: (item)=>set((state)=>{
                const existing = state.items.find((i)=>i.id === item.id);
                if (existing) {
                    return {
                        items: state.items.map((i)=>i.id === item.id ? {
                                ...i,
                                quantity: item.quantity + item.quantity
                            } : i)
                    };
                }
                return {
                    items: [
                        ...state.items,
                        item
                    ]
                };
            }),
        delete: (itemId)=>set((state)=>{
                const existingItem = state.items.find((i)=>i.id === itemId);
                if (!existingItem) {
                    console.error("Item does not exist in this order.");
                    return {}; // Return empty object to not change state
                }
                if (existingItem.quantity > 1) {
                    // Return a new state with the updated quantity
                    return {
                        items: state.items.map((i)=>i.id === itemId ? {
                                ...i,
                                quantity: i.quantity - 1
                            } : i)
                    };
                } else {
                    // Return a new state without the item
                    return {
                        items: state.items.filter((i)=>i.id !== itemId)
                    };
                }
            })
    }));
const handleATCClick = ()=>{
    console.log("added to cart");
};
}}),

};

//# sourceMappingURL=src_lib_useAddToCart_ts_5b621c67._.js.map