module.exports = {

"[project]/src/app/@modal/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_%40modal_layout_tsx_87e89a83._.js.map