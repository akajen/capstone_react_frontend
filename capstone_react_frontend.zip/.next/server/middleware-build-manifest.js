globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/[root-of-the-server]__dff68bce._.js",
      "static/chunks/a14e7_react-dom_638ad3bb._.js",
      "static/chunks/node_modules__pnpm_51c25b77._.js",
      "static/chunks/[root-of-the-server]__49fd8634._.js",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_30656fb6._.js"
    ],
    "/_error": [
      "static/chunks/[root-of-the-server]__427c4f10._.js",
      "static/chunks/a14e7_react-dom_638ad3bb._.js",
      "static/chunks/node_modules__pnpm_51c25b77._.js",
      "static/chunks/[root-of-the-server]__923cb372._.js",
      "static/chunks/pages__error_5771e187._.js",
      "static/chunks/pages__error_a98ada48._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/32a9e_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_60b49885._.js",
    "static/chunks/32a9e_next_dist_compiled_e64c8dbd._.js",
    "static/chunks/32a9e_next_dist_client_56a827c2._.js",
    "static/chunks/32a9e_next_dist_1143052f._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_98bd08c6._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];