(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/32a9e_next_61822ad0._.js",
  "static/chunks/src_app_@modal_layout_tsx_4c52eb39._.js"
],
    source: "dynamic"
});
