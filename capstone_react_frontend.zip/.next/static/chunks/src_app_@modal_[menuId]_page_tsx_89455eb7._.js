(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_@modal_[menuId]_page_tsx_7b8dd8fd._.js"
],
    source: "dynamic"
});
