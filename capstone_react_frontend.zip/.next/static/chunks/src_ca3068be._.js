(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/lib/useAddToCart.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "handleATCClick": (()=>handleATCClick),
    "useAddToCart": (()=>useAddToCart)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$3_$40$types$2b$react$40$_961aaeffa0f0daea64aa5e05def61fc9$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.3_@types+react@_961aaeffa0f0daea64aa5e05def61fc9/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useAddToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$3_$40$types$2b$react$40$_961aaeffa0f0daea64aa5e05def61fc9$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        items: [],
        add: (item)=>set((state)=>{
                const existing = state.items.find((i)=>i.id === item.id);
                if (existing) {
                    return {
                        items: state.items.map((i)=>i.id === item.id ? {
                                ...i,
                                quantity: item.quantity + item.quantity
                            } : i)
                    };
                }
                return {
                    items: [
                        ...state.items,
                        item
                    ]
                };
            }),
        delete: (itemId)=>set((state)=>{
                const existingItem = state.items.find((i)=>i.id === itemId);
                if (!existingItem) {
                    console.error("Item does not exist in this order.");
                    return {}; // Return empty object to not change state
                }
                if (existingItem.quantity > 1) {
                    // Return a new state with the updated quantity
                    return {
                        items: state.items.map((i)=>i.id === itemId ? {
                                ...i,
                                quantity: i.quantity - 1
                            } : i)
                    };
                } else {
                    // Return a new state without the item
                    return {
                        items: state.items.filter((i)=>i.id !== itemId)
                    };
                }
            })
    }));
const handleATCClick = ()=>{
    console.log("added to cart");
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ATCButton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ATCButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$useAddToCart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/useAddToCart.ts [app-client] (ecmascript)");
"use client";
;
;
function ATCButton() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$useAddToCart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["handleATCClick"],
        className: "bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50",
        children: "Add to Cart"
    }, void 0, false, {
        fileName: "[project]/src/components/ATCButton.tsx",
        lineNumber: 5,
        columnNumber: 9
    }, this);
}
_c = ATCButton;
var _c;
__turbopack_context__.k.register(_c, "ATCButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_ca3068be._.js.map