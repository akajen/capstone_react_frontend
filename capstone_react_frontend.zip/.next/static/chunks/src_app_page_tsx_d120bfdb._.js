(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_b5dfdd5f._.js",
  "static/chunks/src_lib_useAddToCart_ts_cc075de2._.js"
],
    source: "dynamic"
});
