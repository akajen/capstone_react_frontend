export default function menuPage(){
    return <></>
}